Parameters:  -d Kog -e 0.001

There are five output files:
1. README.txt
   This file

2. output.1 
   short table, columns:
   1. Query name
   2. Hit Name
   3. E-value
   4. Identity
   5. Score
   6. Start position of query sequence
   7. End position of query sequence
   8. Start position of hit
   9. End position of hit
   10. Hit length

3. output.2
   long table, columns:
   1. Query name
   2. Hit name
   3. E-value
   4. Identity
   5. Score
   6. Start position of query sequence
   7. End position of query sequence
   8. Start position of hit
   9. End position of hit
   10. Description
   11. Class
   12. Class description

4. output.2.family
   counts by family, columns:
   1. COG/KOG/PRK no.
   2. count
   3. description
   4. class
   5. class description

5. output.2.class
   counts by class, columns:
   1. class
   2. count
   3. description 
